# React Native Todo App
Simple React Native Todo App

![React Native Todo App Screenshot](https://i.ibb.co/LtQNxC3/image.png)

You can create task and delete them by clicking on any of the the blue squares. The App was created by following this [tutorial](https://www.youtube.com/watch?v=0kL6nhutjQ8), big thanks to Matt for creating this awesome tutorials.
