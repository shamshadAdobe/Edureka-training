# MovieTicketsBooking_ReactNative

A React-Native app for booking movie tickets using a slick animated UI. 

#### Features
* UI for booking movie tickets on both ios and android
* Movie showing times, dates, and booking options
* Confirmation code

<img src="https://github.com/shamshadAdobe/MovieTicketsBooking_ReactNative/blob/master/img/MovieTicketsBookingGif.gif" alt="DemoLink" width="640" />

#### Technical Stack
* React Native
* Redux
* Babel
* ES6

#### Instructions for running:

###### Note: If you have not done so yet, make sure [Movie Tickets Backend](https://github.com/shamshadAdobe/MovieTicketsBookingBackend_ReactNative) is up and running
1. git clone https://github.com/shamshadAdobe/MovieTicketsBooking_ReactNative.git
2. cd MovieTicketsBooking_ReactNative
3. npm i
4. react-native run-ios

#### Tutorial
